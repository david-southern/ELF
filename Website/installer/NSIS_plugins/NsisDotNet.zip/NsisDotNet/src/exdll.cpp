// This plugin for the NSIS installer will invoke the .NET 2.0 Framework
// installer after it has been downloaded.  It will do its best to make
// the installer run without user input, while giving the user feedback
// in the form of status bars and so on.
// 
// http://www.xobni.com/opensource/NsisDotNet/README.htm
// 
// Copyright (C) 2006 Xobni Corporation
// 
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include "stdafx.h"
#include "windows.h"
#include "Winuser.h"
#include "exdll.h"

HWND g_hwndParent;


//  -----------

HWND hwndParent;
HWND hwndIgnore;

bool foundCancel;
bool foundRetry;
bool foundIgnore;
bool foundListBox;
int numButtons;


BOOL CALLBACK childWindowCallback(HWND hwnd, LPARAM lParam) 
{
	char buf[10];
	GetClassName(hwnd, buf, 10);

	if(strcmp(buf, "Button") == 0) {

		numButtons++;
		GetWindowText(hwnd, buf, 10);
		if(strcmp(buf, "Cancel") == 0) {
			foundCancel = true;
		} else if(strcmp(buf, "&Retry") == 0) {
			foundRetry = true;
		} else if(strcmp(buf, "&Ignore") == 0) {
			foundIgnore = true;
			hwndIgnore = hwnd;
		}

	} else if(strcmp(buf, "ListBox") == 0) {

		foundListBox = true;

	}

	return true;
}

BOOL CALLBACK windowCallback(HWND hwnd, LPARAM lParam) 
{
	foundCancel = false;
	foundRetry = false;
	foundIgnore = false;
	foundListBox = false;
	numButtons = 0;

	EnumChildWindows(hwnd, (WNDENUMPROC)childWindowCallback, 0);

	if(numButtons != 3) {
		return true;
	}
	if(!foundCancel || !foundRetry || !foundIgnore || !foundListBox) {
		return true;
	}

	hwndParent = hwnd;

	return false;
}

bool clickIgnoreIfFound() 
{
	hwndIgnore = 0;
	EnumWindows((WNDENUMPROC)windowCallback, 0);

	if(hwndIgnore != 0) {
		char buf[1024];
		sprintf( buf, "Window handle: %08x\n", hwndIgnore );
		OutputDebugString(buf);
		sprintf( buf, "Parent window handle: %08x\n", hwndParent );
		OutputDebugString(buf);

		SendMessage(hwndIgnore, BM_CLICK, 0, 0);

		return true;
	}

	return false;
}

extern "C" __declspec(dllexport) void	LaunchInstaller( HWND		hwndParent, 
													 int		string_size,
													 char		*variables, 
													 stack_t	**stacktop )
{
	char buf[1024];
	sprintf( buf, "NSIS: Enter1" );
	OutputDebugString(buf);

	g_hwndParent=hwndParent;

	EXDLL_INIT();
	{		
		sprintf( buf, "NSIS: Enter2" );
		OutputDebugString(buf);
		
		STARTUPINFO siInstaller;
		PROCESS_INFORMATION piInstaller;
		memset(&siInstaller, 0, sizeof(siInstaller));
		memset(&piInstaller, 0, sizeof(piInstaller));
		siInstaller.cb = sizeof(siInstaller);

		char pName[1024];
		popstring(pName);
		char pArgs[1024];
		sprintf( pArgs, " /c:\"install.exe /qb\"" );
		
		OutputDebugString(pName);

		if(CreateProcess(pName, pArgs, 0, 0, FALSE, CREATE_DEFAULT_ERROR_MODE, 0, 0, &siInstaller,
				&piInstaller) == FALSE) {

			sprintf( buf, "NSIS: Error in CreateProcess" );
			OutputDebugString(buf);
			return;
		}

		bool ignoreClicked = false;
		while(WaitForSingleObject(piInstaller.hProcess, 0) == WAIT_TIMEOUT) {
			if(!ignoreClicked) {
				ignoreClicked = clickIgnoreIfFound();
			}

			Sleep(50);
		}

		::CloseHandle(piInstaller.hThread);
		::CloseHandle(piInstaller.hProcess);

		sprintf( buf, "NSIS: Exiting" );
		OutputDebugString(buf);
		return;
	}
}

BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
